# SIDEKA DESKTOP
Aplikasi Sistem Informasi Desa dan Kawasan Dengan Python GTK (wxPython)
yang untuk dibangun bagi Pemerintah Desa dengan sistem Desktop khusus pengguna Linux
Sistem Database yang digunakan dengan Menggunakan MySQL yang bersifat Online dan Offline
Bagi Pemerintah Desa yang belum tersedia akses internet dapat melakukan proses offline
untuk seluruh databasenya, sedangkan bagi yang sudah memiliki koneksi internet 
dapat langsung melakukan sinkron database antara database yang tersimpan secara offline
dengan database secara online.

Dengan penggunaan SIDEKA DESKTOP kebutuhan akan akses internet dapat diperkecil karena
yang dilakukan hanyalah pengiriman database sedangkan Layanan Front End berada di desktop.

Penggunaan Python (wxPython) bertujuan agar proses program berjalan tanpa menggunakan 
resource yang besar sesuai dengan kondisi resource komputer yang berada di pedesaan.
